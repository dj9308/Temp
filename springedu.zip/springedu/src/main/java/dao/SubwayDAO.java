package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import vo.subwayVO;

@Repository
public class SubwayDAO {
	@Autowired
	@Qualifier("hiveDataSource")	
	DataSource ds;

	public List<subwayVO> select(int i) {
		List<subwayVO> list = new ArrayList<>();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			conn = ds.getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery("select * from Subway where line = 'line_"+i+"'");
			subwayVO vo = null;
			while(rs.next()) {
				vo = new subwayVO();
				vo.setLine(rs.getString(1));
				vo.setTime(rs.getInt(2));
				vo.setRide(rs.getInt(3));
				vo.setTakeoff(rs.getInt(4));
				list.add(vo);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if( rs != null ) rs.close();
				if( stmt != null ) stmt.close();
				if( conn != null ) conn.close();
			} catch (Exception e) {
				e.printStackTrace();				
			} 
		}
		return list;		
	}
}


