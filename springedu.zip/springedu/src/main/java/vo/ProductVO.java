package vo;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement	
public class ProductVO {
private int p001=0;
private int p002=0;
private int p003=0;

public int getP001() {
	return p001;
}
public void setP001() {
	this.p001 += 1;
}
public int getP002() {
	return p002;
}
public void setP002() {
	this.p002 += 1;
}
public int getP003() {
	return p003;
}
public void setP003() {
	this.p003 += 1;
}


}
