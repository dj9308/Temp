package vo;

public class OnePersonVO {
private String gu;
private String dong;
private int human;


public String getGu() {
	return gu;
}
public void setGu(String gu) {
	this.gu = gu;
}
public String getDong() {
	return dong;
}
public void setDong(String dong) {
	this.dong = dong;
}
public int getHuman() {
	return human;
}
public void setHuman(int human) {
	this.human = human;
}

}
