package vo;

public class subwayVO {
private String line;
private int time;
private int takeoff;
private int ride;

public String getLine() {
	return line;
}
public void setLine(String line) {
	this.line = line;
}
public int getTime() {
	return time;
}
public void setTime(int time) {
	this.time = time;
}
public int getTakeoff() {
	return takeoff;
}
public void setTakeoff(int takeoff) {
	this.takeoff = takeoff;
}
public int getRide() {
	return ride;
}
public void setRide(int ride) {
	this.ride = ride;
}

}
