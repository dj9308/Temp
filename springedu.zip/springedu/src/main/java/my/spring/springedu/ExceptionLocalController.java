package my.spring.springedu;
import java.io.IOException;
import org.springframework.beans.TypeMismatchException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import service.FriendNotFoundException;
import service.FriendService;
import vo.FriendVO;

@Controller
public class ExceptionLocalController {
	@Autowired
	FriendService ms;
	@RequestMapping("/exceptionTest")
	public String detail(int num, Model model) throws FriendNotFoundException {	// thorws 설정 조심
		FriendVO vo = ms.get(num);
		if (vo == null) {
			throw new FriendNotFoundException();	//message가 없는 예외 메서드 불러옴
		}
		model.addAttribute("friend", vo);
		return "friendView";
	}

	@ExceptionHandler(TypeMismatchException.class)
	public ModelAndView handleTypeMismatchException(TypeMismatchException ex) {
		ModelAndView mav = new ModelAndView();
		mav.addObject("msg", "타입을 맞춰주세용!!");
		mav.setViewName("errorPage");
		return mav;
	}

	@ExceptionHandler(FriendNotFoundException.class)
	public String handleNotFoundException() throws IOException {
		return "noFriend";		//nofriend.jsp 가 리턴해버림
	}
	// 식을 넣어서 에러가나는걸 일부러 테스트 해봐야함.
	@ExceptionHandler(IllegalStateException.class)	//남은 형식의 에러 발생시
	public ModelAndView handleIllegalStateException() throws IOException {// 
		ModelAndView mav = new ModelAndView();
		mav.addObject("msg", "num=숫자 형식의 쿼리를 전달하세요!!");
		mav.setViewName("errorPage");
		return mav;
	}	//다른 컨트롤러에서는 적용안됨 (로컬전용)
}// 만약 예외처리 전용 메서드를 만들고 싶을 경우 @controlleradvice(에러전담 클래스)
