package my.spring.springedu;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import dao.NewsDAO;
import vo.NewsVO;

//@Controller

public class NewsController {
	@RequestMapping(value = "/news2")
	//@ResponseBody
	public ModelAndView news(NewsVO vo, String id, String action, 
			String keyword, String option, String search, String writer,
			String title, String content) {
	      ModelAndView mav = new ModelAndView();
	      NewsDAO dao = new NewsDAO();
			if(action!=null) {
				if(action.equals("read") ) {
					vo = dao.listOne(Integer.parseInt(id));
					mav.addObject("vo", vo);
					mav.addObject("list", dao.listAll());
				}else if(action.equals("delete")) {
					if (dao.delete(Integer.parseInt(id)))
						mav.addObject("msg", "뉴스가 성공적으로 삭제되었습니다.");
					else
						mav.addObject("msg", "뉴스를 삭제하는데  실패했습니다.");
					mav.addObject("list", dao.listAll());
				}else if(action.equals("find")) {
					if(option!=null && search!=null) {
								mav.addObject("r_title", dao.search(search,option));

					}
			}else if(action.equals("s_writer")) {
				mav.addObject("r_writer", dao.listWriter(writer));
			}	if(action.equals("insert")) {
				boolean result = dao.insert(vo);
				if (result) {
					mav.addObject("msg", "뉴스가 성공적으로 입력되었습니다.");
				} else {
					mav.addObject("msg", "뉴스 입력에 실패했습니다.");
				}
				
			}else if(action.equals("update")){
				vo.setId(Integer.parseInt(id));
				boolean result = dao.update(vo);
				if(result) {
					mav.addObject("msg", "뉴스가 성공적으로 수정되었습니다.");
				} else {
					mav.addObject("msg", "뉴스 수정에 실패했습니다.");
				}
			}
				
			}else {
				mav.addObject("list", dao.listAll());
			}
			mav.setViewName("news");
			return mav;
		}
}
		
	