package my.spring.springedu;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import vo.StepVO;
// POJO	= PLAIN OLD JAVA OBJECT
@Controller
public class StepController {		
	@RequestMapping(value="/step",
			 method=RequestMethod.POST)
	public String memberHandle(@ModelAttribute("kkk") StepVO vo) {
		// kkk=> stepVO객체를 request 객체를 보관하는데 이름을 붙여준것.
		if(vo.getAge() < 18)
			return "redirect:/resources/stepForm.html";//redirect스키마를 추가해서 돌아감
		System.out.println("[ Information for the passed Command object ]");
		System.out.println(vo.getName());
		System.out.println(vo.getPhoneNumber());
		System.out.println(vo.getAge());
		return  "stepOutput"; //String 리턴이면 view로 직접 전달하는 것이 아님.
		//stepOutput 이라는 이름의 jsp에 보내지게 됨
		/*
		 * <beans:bean
		 * class="org.springframework.web.servlet.view.InternalResourceViewResolver">
		 * <beans:property name="prefix" value="/WEB-INF/views/" /> <beans:property
		 * name="suffix" value=".jsp" /> </beans:bean>
		 */
	}
}
