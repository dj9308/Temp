package my.spring.springedu;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
@Controller
public  class CalcController {
	@RequestMapping("/CalcController")
	public ModelAndView proc(String giho ,int num1, int num2) {
		ModelAndView mav = new ModelAndView();
	int result = 0;
	
	switch(giho) {
	case "+":
		result = num1+num2;
		break;
	case "-":
		result = num1-num2;	
		break;
	case "*":
		result = num1*num2;
		break;
	case "/":
		if(num2==0) {
			mav.addObject("fail", "나눌때 분모는 0이 될 수 없습네다");	
		}else
			result = num1/num2;
		break;
		
	}
		mav.addObject("result", result);	
	mav.setViewName("calcResult");
		return mav;
	}	
}