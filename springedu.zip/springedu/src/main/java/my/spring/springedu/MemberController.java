package my.spring.springedu;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import vo.MemberVO;
@Controller
public class MemberController {
	@RequestMapping("/MemberController")
	public ModelAndView proc(MemberVO vo) {
		ModelAndView mav = new ModelAndView();
		if(vo.getName().equals(""))
			vo.setName("없음");
		if(vo.getEmail().equals(""))
			vo.setEmail("없음");
		if(vo.getTel().equals(""))
			vo.setTel("없음");
		if(vo.getPasswd().equals(""))
			vo.setPasswd("없음");
		
	mav.setViewName("memberView");
		return mav;
	}	
}																					