package my.spring.springedu;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import dao.OnePersonDAO;
import vo.OnePersonVO;

@Controller
public class OnePersonController {
	@Autowired
	OnePersonDAO dao;

	@RequestMapping("/one")
	ModelAndView createTable(String action, String search) {
		ModelAndView mav = new ModelAndView();
		if(action!=null) {
			if(action.equals("one")) {
				List<OnePersonVO> list = dao.select1();
				mav.addObject("title", "1인 가구가 많은 순서");
				mav.addObject("list", list);
			}else if(action.equals("two")) {
				List<OnePersonVO> list = dao.select2();
				mav.addObject("title", "구별 1인 가구 명수");
				mav.addObject("list", list);
			}else if(action.equals("three")) {
				OnePersonVO vo = dao.select3();
				mav.addObject("title", "1인 가구수가 제일 많은 동의 구 이름과 동 이름");
				mav.addObject("list2", vo);
			}else if(action.equals("four")) {
				OnePersonVO vo = dao.select4();
				mav.addObject("title", "1인 가구수가 제일 많은 구 이름");
				mav.addObject("list2", vo);
			}else {
				mav.addObject("msg","잘못 들어오셨습네다.");
			}
		}if(search!=null) {
			List<OnePersonVO> list = dao.search(search);
			mav.addObject("list", list);
			if(search.equals("")) mav.addObject("msg", "잘좀 입력하세요"); 
		}
		
		mav.setViewName("OnePerson");
		return mav;
	}

}
