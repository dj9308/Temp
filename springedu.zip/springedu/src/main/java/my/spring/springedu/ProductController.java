package my.spring.springedu;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import vo.ProductVO;
@Controller 
@SessionAttributes({"p001", "p002","p003"})
public class ProductController {
	
	@ModelAttribute("p001")
	public ProductVO countP001() {	
		return new ProductVO();
	}
	@ModelAttribute("p002")
	public ProductVO countP002() {
		return new ProductVO();
	}	
	@ModelAttribute("p003")
	public ProductVO countP003() {
		return new ProductVO();
	}

	@RequestMapping(value="/productView")
	public void handle(@ModelAttribute("p001")ProductVO vo1, 
			      @ModelAttribute("p002")ProductVO vo2,
			      @ModelAttribute("p003")ProductVO vo3,
			      HttpSession s, HttpServletRequest req) {
		String pid =req.getParameter("pid");
		if(pid.equals("p001"))
		vo1.setP001();
		else if(pid.equals("p002"))
		vo2.setP002();
		else
		vo3.setP003();
	}
	@RequestMapping(value = "/delete", produces = "application/json; charset=utf-8")
	@ResponseBody
	public void handle(SessionStatus s) {
		s.setComplete();	//세션객체의 값들을 리셋시키는것.

	}
}
