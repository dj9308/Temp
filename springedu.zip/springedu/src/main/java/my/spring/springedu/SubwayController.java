package my.spring.springedu;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import dao.SubwayDAO;
import vo.subwayVO;

@Controller
public class SubwayController {
	@Autowired
	SubwayDAO dao;

	@RequestMapping("/subway")
	ModelAndView createTable(int num) {
		ModelAndView mav = new ModelAndView();
		List<subwayVO> list = dao.select(num);
		mav.addObject("list", list);
		
		mav.setViewName("Subway");
		return mav;
	}

}
