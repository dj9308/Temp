package service;

import org.springframework.stereotype.Service;
import vo.LoginVO;

@Service
public class LoginService {
	public boolean get(String id, String passwd) {
		LoginVO vo = null;
		if (id.equals("spring") && passwd.equals("@1234")) {
			vo = new LoginVO();
			vo.setId(id);
			vo.setPasswd(passwd);	
			return true;
		}else
			return false;
	}
}
