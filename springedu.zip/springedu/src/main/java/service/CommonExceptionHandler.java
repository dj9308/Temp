package service;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice		//어떤 컨트롤러든 요청되었을때 호출 가능
// 이렇게 설정하면 객체에 따로 thorws 할 필요 없음
public class CommonExceptionHandler {
    @ExceptionHandler(RuntimeException.class)
    private ModelAndView errorModelAndView(Exception ex) {
       ModelAndView modelAndView = new ModelAndView();
       modelAndView.setViewName("commonErrorPage");
       modelAndView.addObject("msg", "RuntimeException은 내가 다 잡는다!!!" );
       modelAndView.addObject("exceptionInfo", ex );
       return modelAndView;
   }
}

