package service;

import java.util.ArrayList;

import org.springframework.ui.Model;

import dao.NewsDAO;
import vo.NewsVO;

public class newsService {
	
	public void service (Model model){
		NewsDAO dao = new NewsDAO();
		
		ArrayList<NewsVO> vo = (ArrayList<NewsVO>) dao.listAll();
		model.addAttribute("list", vo);	//list에 vo 객체 연결
	}
}
